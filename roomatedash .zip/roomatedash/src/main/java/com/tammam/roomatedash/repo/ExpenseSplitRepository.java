package com.tammam.roomatedash.repo;

import com.tammam.roomatedash.model.ExpenseSplit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExpenseSplitRepository extends JpaRepository<ExpenseSplit, Long> {}
